package com.assignment.BDIPLUSAssignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BdiPlusAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
